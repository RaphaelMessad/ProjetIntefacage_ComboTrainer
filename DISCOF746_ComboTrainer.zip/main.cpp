#include "mbed.h"
#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery_ts.h"

DigitalIn Up(PC_7); //joystick vers le bas
DigitalIn Down(PC_6); //joystick vers le haut
DigitalIn Right(PG_6); //joystick vers la gauche
DigitalIn Left(PB_4); //joystick vers la droite
DigitalIn Blue(PG_7);
DigitalIn Green(PI_0);
DigitalIn Black(PH_6);

Timer t;

#define title_0 0
#define menu_1 1
#define menu_2 2
#define menu_3 3
#define menu_1_easy 4
#define menu_1_medium 5
#define menu_1_hard 6
#define menu_1_easy_0 7
#define menu_1_easy_1 8
#define menu_1_easy_2 9
#define menu_1_easy_3 10
#define menu_1_easy_4 11
#define menu_1_easy_5 12
#define menu_1_easy_6 13
#define menu_1_easy_7 14
#define menu_1_easy_8 15
#define menu_1_easy_9 16
#define menu_1_medium_0 17
#define menu_1_medium_1 18
#define menu_1_medium_2 19
#define menu_1_medium_3 20
#define menu_1_medium_4 21
#define menu_1_medium_5 22
#define menu_1_medium_6 23
#define menu_1_medium_7 24
#define menu_1_medium_8 25
#define menu_1_medium_9 26
#define menu_1_medium_10 27
#define menu_1_medium_11 28
#define menu_1_medium_12 29
#define menu_1_medium_13 30
#define menu_1_medium_14 31
#define menu_1_medium_15 32
#define menu_1_medium_16 33
#define menu_1_medium_17 34
#define menu_1_hard_0 35
#define menu_1_hard_1 36
#define menu_1_hard_2 37
#define menu_1_hard_3 38
#define menu_1_hard_4 39
#define menu_1_hard_5 40
#define menu_1_hard_6 41
#define menu_1_hard_7 42
#define menu_1_hard_8 43
#define menu_1_hard_9 44
#define menu_1_hard_10 45
#define menu_1_hard_11 46
#define menu_1_hard_12 47
#define menu_1_hard_13 48
#define menu_1_hard_14 49
#define menu_1_hard_15 50
#define menu_1_hard_16 51
#define menu_1_hard_17 52
#define menu_1_hard_18 53
#define menu_1_hard_19 54
#define menu_1_hard_20 55
#define menu_1_hard_21 56
#define menu_1_hard_22 57
#define menu_1_hard_23 120
#define menu_1_hard_24 121
#define menu_1_hard_25 122
#define menu_1_hard_26 123
#define tr1 60 
#define tr2 61 
#define tr3 62
#define tr4 63
#define tr5 64
#define tr6 65
#define tr7 66
#define tr8 67
#define tr9 68 
#define tr10 69
#define tr11 70
#define tr12 71
#define tr13 72
#define tr14 73
#define tr15 74
#define tr16 75
#define tr17 76
#define tr18 77
#define tr19 78
#define tr20 79
#define tr21 80
#define tr22 81
#define tr23 82
#define tr24 83
#define tr25 84
#define tr26 85
#define tr27 86
#define tr28 87
#define tr29 88
#define tr30 89
#define tr31 90
#define tr32 91
#define tr33 92
#define tr34 93
#define tr35 94
#define tr36 95
#define tr37 96
#define tr38 97
#define tr39 98
#define tr40 99
#define tr41 100
#define tr42 101
#define tr43 102
#define tr44 103
#define tr45 104
#define tr46 105
#define tr47 106
#define tr48 124
#define tr49 125
#define tr50 126
#define tr51 127
#define tr52 128
#define tr53 129
#define tr54 130
#define tr55 131
#define tr56 132
#define tr57 133
#define debug 134
#define menu_1_easy_fail 107
#define menu_1_medium_fail 108
#define menu_1_hard_fail 109
#define menu_1_easy_win 110
#define menu_1_medium_win 111
#define menu_1_hard_win 112
#define menu_1_easy_cleanupL 113
#define menu_1_medium_cleanupL 114
#define menu_1_hard_cleanupL 115
#define menu_1_easy_cleanupR 116
#define menu_1_medium_cleanupR 117
#define menu_1_hard_cleanupR 118
#define menu_1_easy_cleanup 119


uint8_t idx;
uint16_t x=0, y=0;
TS_StateTypeDef TS_State;
int state = 0;

void Menu(void);

int main()
{
    TS_StateTypeDef TS_State;
    uint8_t idx;
    uint8_t text[30], string[8];
    uint8_t status;
    uint8_t cleared = 0;
    uint8_t prev_nb_touches = 0;

    BSP_LCD_Init();
    BSP_LCD_LayerDefaultInit(LTDC_ACTIVE_LAYER, LCD_FB_START_ADDRESS);
    BSP_LCD_SelectLayer(LTDC_ACTIVE_LAYER);

    BSP_LCD_DisplayStringAt(0, LINE(5), (uint8_t *)"TOUCHSCREEN DEMO", CENTER_MODE);
    HAL_Delay(1000);

    status = BSP_TS_Init(BSP_LCD_GetXSize(), BSP_LCD_GetYSize());
    if (status != TS_OK) {
        BSP_LCD_Clear(LCD_COLOR_RED);
        BSP_LCD_SetBackColor(LCD_COLOR_RED);
        BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
        BSP_LCD_DisplayStringAt(0, LINE(5), (uint8_t *)"TOUCHSCREEN INIT FAIL", CENTER_MODE);
    } else {
        BSP_LCD_Clear(LCD_COLOR_GREEN);
        BSP_LCD_SetBackColor(LCD_COLOR_GREEN);
        BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
        BSP_LCD_DisplayStringAt(0, LINE(5), (uint8_t *)"TOUCHSCREEN INIT OK", CENTER_MODE);
    }

    HAL_Delay(1000);
    BSP_LCD_SetFont(&Font12);
    BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
    BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
    BSP_LCD_Clear(LCD_COLOR_WHITE);

    while(1) 
    {
      
      Menu();

    }
}

void Menu(void)
{
    state = title_0;
    int length = 160, height = 90, flag =0;
    int Xrect = 0, Yrect =0;
    uint8_t idx;
    TS_StateTypeDef TS_State;


    while(1)
    {
        switch(state)
        {
            case title_0 :
            flag = 0;
            x = 0;
            y = 0;
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_DrawRect(80, 45, 320, 135); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font20);
            BSP_LCD_DisplayStringAt(160, 112, (uint8_t *)"Combo Trainer", LEFT_MODE);
            BSP_TS_GetState(&TS_State);

            for (idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[idx];
                y = TS_State.touchY[idx];
            }

            if ((x<480 && x>0)&&(y<270 && y>0) && flag == 0) 
            {
                HAL_Delay(250);
                flag =1;
                state = menu_1_easy_cleanup;
            }

            else if(flag == 1)
            {
                BSP_LCD_Clear(LCD_COLOR_RED);
                HAL_Delay(1500);   
                state = tr9;
            }
            break;
            
            case menu_1_easy_cleanup:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            x = y = 0;
            state = menu_1_easy;
            break;


            case menu_1_easy_cleanupL:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            x = y = 0;
            state = menu_1_easy;
            break;

            case menu_1_easy_cleanupR:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            x = y = 0;
            state = menu_1_easy;
            break;

            case menu_1_medium_cleanupL:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            x = y = 0;
            state = menu_1_medium;
            break;

            case menu_1_medium_cleanupR:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            x = y = 0;
            state = menu_1_medium;
            break;

            case menu_1_hard_cleanupL:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            x = y = 0;
            state = menu_1_hard;
            break;

            case menu_1_hard_cleanupR:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            x = y = 0;
            state = menu_1_hard;
            break;

            

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_easy :
            HAL_Delay(250);
            x=0;
            y=0;
            BSP_TS_GetState(&TS_State);
            BSP_LCD_DrawRect(80, 25, 320, 90); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(180, 67, (uint8_t *)"Enchainement Facile", LEFT_MODE);
            BSP_LCD_DrawRect(160, 180, 160, 90);
            BSP_LCD_SetFont(&Font20);
            BSP_LCD_DisplayStringAt(220, 225, (uint8_t *)"Jouer", LEFT_MODE);
            BSP_LCD_DrawRect(400, 135, 80, 45); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(410,157, (uint8_t *)"Moyen", LEFT_MODE);
            BSP_LCD_DrawRect(0, 135, 80, 45); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(5, 157, (uint8_t *)"Difficile", LEFT_MODE);
            
 
            for (idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[idx];
                y = TS_State.touchY[idx];
            }

            if ((x < 350 && x > 130) && (y < 270 && y > 150) )
            { 
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                state = menu_1_easy_0;
            }

            if((x <= 480 && x >= 400) && (y < 180 && y > 135))
            { 
                state = menu_1_medium_cleanupL;
            }

            if((x < 80 && x > 0) && (y < 180 && y > 135))
            {
                state = menu_1_hard_cleanupR;
            }

            break;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_medium :
            HAL_Delay(250);
            x=0;
            y=0;
            BSP_TS_GetState(&TS_State);
            BSP_LCD_DrawRect(80, 25, 320, 90); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(180, 67, (uint8_t *)"Enchainement Moyen", LEFT_MODE);
            BSP_LCD_DrawRect(160, 180, 160, 90);
            BSP_LCD_SetFont(&Font20);
            BSP_LCD_DisplayStringAt(220, 225, (uint8_t *)"Jouer", LEFT_MODE);
            BSP_LCD_DrawRect(400, 135, 80, 45); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(400,157, (uint8_t *)"Diffcile", LEFT_MODE);
            BSP_LCD_DrawRect(0, 135, 80, 45); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(5, 157, (uint8_t *)"Facile", LEFT_MODE);

            for (idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[idx];
                y = TS_State.touchY[idx];
            }


            if ((x < 320 && x > 160) && (y < 270 && y > 180) )
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                state = menu_1_medium_0;
            }

            if((x <= 480 && x >= 400) && (y < 180 && y > 135))
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                state = menu_1_hard_cleanupL;
            }

            if((x < 80 && x > 0) && (y < 180 && y > 135))
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                state = menu_1_easy_cleanupR;
            }

            break;
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_hard :
            HAL_Delay(250);
            x=0;
            y=0;
            BSP_TS_GetState(&TS_State);
            BSP_LCD_DrawRect(80, 25, 320, 90); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(180, 67, (uint8_t *)"Enchainement Difficile", LEFT_MODE);
            BSP_LCD_DrawRect(160, 180, 160, 90);
            BSP_LCD_SetFont(&Font20);
            BSP_LCD_DisplayStringAt(220, 225, (uint8_t *)"Jouer", LEFT_MODE);
            BSP_LCD_DrawRect(400, 135, 80, 45); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(400,157, (uint8_t *)"Facile", LEFT_MODE);
            BSP_LCD_DrawRect(0, 135, 80, 45); //Position en X, Position en Y, Longueur, Hauteur
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(5, 157, (uint8_t *)"Moyen", LEFT_MODE);

            for (idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[idx];
                y = TS_State.touchY[idx];
            }


            if ((x < 320 && x > 160) && (y < 270 && y > 180) )
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                state = menu_1_hard_1;
            }

            if((x <= 480 && x >= 400) && (y < 180 && y > 135))
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                state = menu_1_easy_cleanupL;
            }

            if((x < 80 && x > 0) && (y < 180 && y > 135))
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                state = menu_1_medium_cleanupR;
            }

            break;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_easy_fail :
                if(Up==0)
                {
                    BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                    HAL_Delay(150);
                    state = title_0;
                }
            break;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_medium_fail:
            if (Up == 0)
            {
                HAL_Delay(150);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                state = title_0;
            }
            break;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_hard_fail :

            break;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_easy_0:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = HAUT B B BAS DROITE V V BAS N", LEFT_MODE);
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(160, 180, (uint8_t *)"Premiere touche pour commencer", LEFT_MODE);

            if (Down !=0)
            {
                state = tr1;
            }
            break;

            case tr1:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Down ==0)state = menu_1_easy_1;
            break;
            

            case menu_1_easy_1:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] B B BAS DROITE V V BAS N", LEFT_MODE);

            //Fleche vers le haut
            BSP_LCD_DrawLine(240, 225, 240, 90);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 135, 240, 90);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 135, 240, 90);// (Position X1, Position Y2, Postion X2, Position Y2)


            if(Blue == 0 ) state = tr2;

            else if(Down != 0 || Left !=0 || Up !=0 || Right != 0 || Green ==0 || Black ==0) 
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr2:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0) state = menu_1_easy_2;
            break;

            case menu_1_easy_2:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] [B] B BAS DROITE V V BAS N", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if(Blue == 0 ) state = tr3;

            else if(Down != 0 || Left !=0 || Up !=0 || Right != 0 || Green ==0 || Black ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr3 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0) state = menu_1_easy_3;
            break;

            case menu_1_easy_3:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] [B] [B] BAS DROITE V V BAS N", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if(Up != 0 ) state = tr4;

            else if(Down != 0 || Left !=0 || Blue ==0 || Right != 0 || Green ==0 || Black ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr4:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up==0) state = menu_1_easy_4;
            break;

            case menu_1_easy_4:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] [B] [B] [BAS] DROITE V V BAS N", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if(Left != 0 ) state = tr5;

            else if(Down != 0 || Up !=0 || Blue ==0 || Right != 0 || Green ==0 || Black ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }

            break;


            case tr5:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Left ==0) state = menu_1_easy_5;
            break;


            case menu_1_easy_5:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] [B] [B] [BAS] [DROITE] V V BAS N", LEFT_MODE);

            //Fleche ver la droite
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 135, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 225, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if(Green == 0 ) state = tr6;

            else if(Down != 0 || Up !=0 || Blue ==0 || Right != 0 || Left !=0 || Black ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr6 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Green!=0) state = menu_1_easy_6;
            HAL_Delay(100);
            break;

            case menu_1_easy_6:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] [B] [B] [BAS] [DROITE] [V] V BAS N", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Vert", LEFT_MODE);

            if(Green == 0 ) state = tr7;

            else if(Down != 0 || Up !=0 || Blue == 0 || Right != 0 || Left !=0 || Black ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }

            break;

            case tr7:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Green!=0) state = menu_1_easy_7;
            HAL_Delay(100);
            break;
            
            case menu_1_easy_7:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] [B] [B] [BAS] [DROITE] [V] [V] BAS N", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Vert", LEFT_MODE);

            if(Up != 0 ) state = tr8;

            else if(Green == 0 || Down !=0 || Blue ==0 || Right != 0 || Left !=0 || Black ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }

            break;
            
            case tr8 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up==0) state = menu_1_easy_8;
            break;
            
            case menu_1_easy_8:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [HAUT] [B] [B] [BAS] [DROITE] [V] [V] [BAS] N", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if(Black == 0 ) 
            {
                state = tr9;
            }

            else if(Green == 0 || Down !=0 || Blue ==0 || Right != 0 || Left !=0 || Up !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);

                if(Down !=0)state = menu_1_easy_fail;
            }

            break;

            case tr9 :
            HAL_Delay(150);
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(flag == 1)state = menu_1_easy_9;
            break;

            case menu_1_easy_9:
            x=0;
            y=0;

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(80, 50, (uint8_t *)"Combo = Enchainement termine", LEFT_MODE);
            
            /*BSP_LCD_DrawRect(80,135,160,90);
            BSP_LCD_FillRect(80,135,160,90);*/
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(90, 180, (uint8_t *)"Rejouer", LEFT_MODE);

            /*BSP_LCD_DrawRect(240,135,160,90);
            BSP_LCD_FillRect(240,135,160,90);*/
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(320, 180, (uint8_t *)"Menu", LEFT_MODE);

            BSP_TS_GetState(&TS_State);
            for (idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[0];
                y = TS_State.touchY[0];
            }

            if(Left !=0 ) state = tr11;
            else if(Right !=0 ) state = tr10;

            break;

            case tr10 :
            if (Right == 0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                HAL_Delay(150);
                state = menu_1_easy_0;
            }
            break;

            case tr11 :
            
            if (Left==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                HAL_Delay(150);
                state = title_0;
            }
            break;
            
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_medium_0 :

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = Droite Droite Bas V V Haut B ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(160, 180, (uint8_t *)"Premiere touche pour commencer", LEFT_MODE);

            if (Left !=0)
            {
                state = tr12;
            }
            else if(Green == 0 || Down !=0 || Blue ==0 || Right != 0 || Black ==0 || Up !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr12:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Left==0)state = menu_1_medium_1;
            break;

            case menu_1_medium_1 :

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] Droite Bas V V Haut B ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);

            //Fleche ver la droite
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 135, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 225, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Left !=0)
            {
                state = tr13;
            }
            else if(Green == 0 || Down !=0 || Blue ==0 || Right != 0 || Black ==0 || Up !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_medium_fail;
            }

            break;

            case tr13:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Left==0)state = menu_1_medium_2;
            break;

            case menu_1_medium_2 :

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] Bas V V Haut B ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);

            //Fleche ver la droite
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 135, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 225, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Up !=0)
            {
                state = tr14;
            }
            else if(Green == 0 || Down !=0 || Blue ==0 || Right != 0 || Black ==0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }

            break;

            case tr14:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up==0)state = menu_1_medium_3;
            break;

            case menu_1_medium_3 :

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] V V Haut B ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Green ==0)
            {
                state = tr15;
            }
            else if(Up != 0 || Down !=0 || Blue ==0 || Right != 0 || Black ==0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }

            break;

            case tr15:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Green!=0)state = menu_1_medium_4;
            break;

            case menu_1_medium_4 :

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] V Haut B ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Vert", LEFT_MODE);

            if (Green ==0)
            {
                state = tr16;
            }
            else if(Up != 0 || Down !=0 || Blue ==0 || Right != 0 || Black ==0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr16:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Green!=0)state = menu_1_medium_5;
            break;

            case menu_1_medium_5 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] Haut B ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Vert", LEFT_MODE);

            if (Down !=0)
            {
                state = tr17;
            }
            else if(Green == 0 || Up !=0 || Blue ==0 || Right != 0 || Black ==0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr17:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Down==0)state = menu_1_medium_6;
            break;

            case menu_1_medium_6 :

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] B ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);

            //Fleche vers le haut
            BSP_LCD_DrawLine(240, 270, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Blue ==0)
            {
                state = tr18;
            }
            else if(Green == 0 || Down !=0 || Up !=0 || Right != 0 || Black ==0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }

            break;

            case tr18:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0)state = menu_1_medium_7;
            break;

            case menu_1_medium_7 :

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" B Bas N Haut Droite B B Bas N ", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);
            if (Blue ==0)
            {
                state = tr19;
            }
            else if(Green == 0 || Down !=0 || Up !=0 || Right != 0 || Black ==0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr19:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0)state = menu_1_medium_8;
            break;

            case menu_1_medium_8 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] Bas N Haut Droite B B Bas N ", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Up !=0)
            {
                state = tr20;
            }
            else if(Green == 0 || Blue ==0 || Down !=0 || Right != 0 || Black ==0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr20:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up ==0)state = menu_1_medium_9;
            break;

            case menu_1_medium_9 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] [Bas] N Haut Droite B B Bas N ", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Black ==0)
            {
                state = tr21;
            }
            else if(Green == 0 || Blue ==0 || Up !=0 || Right != 0 || Down!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr21:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Black !=0)state = menu_1_medium_10;
            break;

            case menu_1_medium_10 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] [Bas] [N] Haut Droite B B Bas N ", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Noir", LEFT_MODE);

            if (Down !=0)
            {
                state = tr22;
            }
            else if(Green == 0 || Blue ==0 || Black ==0 || Right != 0 || Up!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr22:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Down ==0)state = menu_1_medium_11;
            break;

            case menu_1_medium_11 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] [Bas] [N] [Haut] Droite B B Bas N ", LEFT_MODE);

            //Fleche vers le haut
            BSP_LCD_DrawLine(240, 270, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Left !=0)
            {
                state = tr23;
            }
            else if(Green == 0 || Blue ==0 || Black ==0 || Right != 0 || Down!=0 || Up !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr23:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Left ==0)state = menu_1_medium_12;
            break;

            case menu_1_medium_12 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] [Bas] [N] [Haut] [Droite] B B Bas N ", LEFT_MODE);

            //Fleche ver la droite
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 135, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 225, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Blue ==0)
            {
                state = tr24;
            }
            else if(Green == 0 || Left !=0 || Black ==0 || Right != 0 || Down!=0 || Up !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr24:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue !=0)state = menu_1_medium_13;
            break;

            case menu_1_medium_13 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] [Bas] [N] [Haut] [Droite] [B] B Bas N ", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Blue ==0)
            {
                state = tr25;
            }
            else if(Green == 0 || Left !=0 || Black ==0 || Right != 0 || Down!=0 || Up !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr25:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue !=0)state = menu_1_medium_14;
            break;

            case menu_1_medium_14 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] [Bas] [N] [Haut] [Droite] [B] [B] Bas N ", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Up !=0)
            {
                state = tr26;
            }
            else if(Green == 0 || Left !=0 || Black ==0 || Right != 0 || Down!=0 || Blue ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr26:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up ==0)state = menu_1_medium_15;
            break;

            case menu_1_medium_15 :
            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bas] [V] [V] [Haut] [B] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)" [B] [Bas] [N] [Haut] [Droite] [B] [B] [Bas] N ", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Black ==0)
            {
                state = tr27;
            }
            else if(Green == 0 || Left !=0 || Up!=0 || Right != 0 || Down!=0 || Blue ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Up = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr27:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Black!=0)state = menu_1_medium_16;
            break;

            case menu_1_medium_16 :
            
            x=0;
            y=0;

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(80, 50, (uint8_t *)"Combo = Enchainement termine", LEFT_MODE);
            
            /*BSP_LCD_DrawRect(80,135,160,90);
            BSP_LCD_FillRect(80,135,160,90);*/
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(90, 180, (uint8_t *)"Rejouer", LEFT_MODE);

            /*BSP_LCD_DrawRect(240,135,160,90);
            BSP_LCD_FillRect(240,135,160,90);*/
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(320, 180, (uint8_t *)"Menu", LEFT_MODE);

            BSP_TS_GetState(&TS_State);
            for (idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[0];
                y = TS_State.touchY[0];
            }

            if(Left !=0 ) state = tr29;
            else if(Right !=0 ) state = tr28;

            break;


            case tr28:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            HAL_Delay(150);
            state = menu_1_medium_0;
            break;

            case tr29:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            HAL_Delay(150);
            state = title_0;
            break;


            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            case menu_1_hard_1:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = Droite Droite Bleu Bleu Bas Noir ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        Haut Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            if (Left !=0)
            {
                state = tr31;
            }
            else if(Green == 0 || Black ==0 || Up!=0 || Right != 0 || Down!=0 || Blue ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;
            
            case tr31 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Left==0)state = menu_1_hard_2;
            break;

            case menu_1_hard_2:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] Droite Bleu Bleu Bas Noir ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        Haut Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche ver la droite
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 135, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 225, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Left !=0)
            {
                state = tr33;
            }
            else if(Green == 0 || Black ==0 || Up!=0 || Right != 0 || Down!=0 || Blue ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr33 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Left==0)state = menu_1_hard_3;
            break;


            case menu_1_hard_3:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] Bleu Bleu Bas Noir ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        Haut Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche ver la droite
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 135, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 225, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Blue ==0)
            {
                state = tr34;
            }
            else if(Green == 0 || Black ==0 || Up!=0 || Right != 0 || Down!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr34 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0)state = menu_1_hard_4;
            break;

            case menu_1_hard_4:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] Bleu Bas Noir ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        Haut Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Blue ==0)
            {
                state = tr35;
            }
            else if(Green == 0 || Black ==0 || Up!=0 || Right != 0 || Down!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr35 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0)state = menu_1_hard_5;
            break;

            case menu_1_hard_5:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] Bas Noir ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        Haut Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Up !=0)
            {
                state = tr36;
            }
            else if(Green == 0 || Black ==0 || Blue==0 || Right != 0 || Down!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr36 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up==0)state = menu_1_hard_6;
            break;

            case menu_1_hard_6:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] Noir ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        Haut Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Black ==0)
            {
                state = tr37;
            }
            else if(Green == 0 || Up !=0 || Blue==0 || Right != 0 || Down!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr37 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Black!=0)state = menu_1_hard_7;
            break;

            case menu_1_hard_7:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        Haut Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Noir", LEFT_MODE);

            if (Down !=0)
            {
                state = tr38;
            }
            else if(Green == 0 || Black ==0 || Blue==0 || Right != 0 || Up!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr38 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Down==0)state = menu_1_hard_8;
            break;

            case menu_1_hard_8:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] Gauche Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche vers le haut
            BSP_LCD_DrawLine(240, 270, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Right !=0)
            {
                state = tr39;
            }
            else if(Green == 0 || Black ==0 || Blue==0 || Up != 0 || Down!=0 || Left !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr39 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Right==0)state = menu_1_hard_9;
            break;

            case menu_1_hard_9:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] Droite Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche ver la gauche
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 135);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Left !=0)
            {
                state = tr40;
            }
            else if(Green == 0 || Black ==0 || Blue==0 || Up != 0 || Down!=0 || Right !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr40 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Left==0)state = menu_1_hard_10;
            break;

            case menu_1_hard_10:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] Vert Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche ver la droite
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 135, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(240, 225, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Green ==0)
            {
                state = tr41;
            }
            else if(Left != 0 || Black ==0 || Blue==0 || Up != 0 || Down!=0 || Right !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr41 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Green!=0)state = menu_1_hard_11;
            break;

            case menu_1_hard_11:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] Bleu Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Vert", LEFT_MODE);

            if (Blue ==0)
            {
                state = tr42;
            }
            else if(Left != 0 || Black ==0 || Green==0 || Up != 0 || Down!=0 || Right !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr42 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0)state = menu_1_hard_12;
            break;

            case menu_1_hard_12:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] Vert Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Green ==0)
            {
                state = tr43;
            }
            else if(Left != 0 || Black ==0 || Blue==0 || Up != 0 || Down!=0 || Right !=0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr43 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Green!=0)state = menu_1_hard_13;
            break;

            case menu_1_hard_13:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] Gauche ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Vert", LEFT_MODE);

            if (Right !=0)
            {
                state = tr44;
            }
            else if(Left != 0 || Black ==0 || Blue==0 || Up != 0 || Down!=0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr44 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Right==0)state = menu_1_hard_14;
            break;
            
            case menu_1_hard_14:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        Bas Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche ver la gauche
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 135);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Up !=0)
            {
                state = tr45;
            }
            else if(Left != 0 || Black ==0 || Blue==0 || Down != 0 || Right!=0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr45 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up==0)state = menu_1_hard_15;
            break;

            case menu_1_hard_15:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        [Bas] Noir Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Black ==0)
            {
                state = tr46;
            }
            else if(Left != 0 || Up !=0 || Blue==0 || Down != 0 || Right!=0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr46 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Black!=0)state = menu_1_hard_16;
            break;

            case menu_1_hard_16:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        [Bas] [Noir] Haut Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Noir", LEFT_MODE);

            if (Down !=0)
            {
                state = tr47;
            }
            else if(Left != 0 || Black ==0 || Blue==0 || Up!= 0 || Right!=0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr47 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Down==0)state = menu_1_hard_17;
            break;

            case menu_1_hard_17:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        [Bas] [Noir] [Haut] Gauche Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche vers le haut
            BSP_LCD_DrawLine(240, 270, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 225, 240, 180);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Right !=0)
            {
                state = tr48;
            }
            else if(Left != 0 || Black ==0 || Blue==0 || Up != 0 || Down!=0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            
            case tr48 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Right==0)state = menu_1_hard_18;
            break;

            case menu_1_hard_18:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        [Bas] [Noir] [Haut] [Gauche] Bleu Bleu Bas Vert", LEFT_MODE);

            //Fleche ver la gauche
            BSP_LCD_DrawLine(160, 180, 320, 180);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 135);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Blue ==0)
            {
                state = tr49;
            }
            else if(Left != 0 || Black ==0 || Right!=0 || Up != 0 || Down!=0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr49 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0)state = menu_1_hard_19;
            break;

            case menu_1_hard_19:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        [Bas] [Noir] [Haut] [Gauche] [Bleu] Bleu Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Blue ==0)
            {
                state = tr50;
            }
            else if(Left != 0 || Black ==0 || Right!=0 || Up != 0 || Down!=0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr50 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Blue!=0)state = menu_1_hard_20;
            break;

            case menu_1_hard_20:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        [Bas] [Noir] [Haut] [Gauche] [Bleu] [Bleu] Bas Vert", LEFT_MODE);

            BSP_LCD_DrawCircle(240, 180, 45);// (Position X, Position Y, Rayon)
            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(220, 175, (uint8_t *)"Bleu", LEFT_MODE);

            if (Up!=0)
            {
                state = tr51;
            }
            else if(Left != 0 || Black ==0 || Right!=0 || Down != 0 || Blue==0 || Green ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr51 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Up==0)state = menu_1_hard_21;
            break;

            case menu_1_hard_21:

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_DisplayStringAt(0, 50, (uint8_t *)"Combo = [Droite] [Droite] [Bleu] [Bleu] [Bas] [Noir] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 83, (uint8_t *)"        [Haut] [Gauche] [Droite] [Vert] [Bleu] [Vert] [Gauche] ", LEFT_MODE);
            BSP_LCD_DisplayStringAt(0, 113, (uint8_t *)"        [Bas] [Noir] [Haut] [Gauche] [Bleu] [Bleu] [Bas] Vert", LEFT_MODE);

            //Fleche vers le bas
            BSP_LCD_DrawLine(240, 135, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(160, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)
            BSP_LCD_DrawLine(320, 180, 240, 225);// (Position X1, Position Y2, Postion X2, Position Y2)

            if (Green ==0)
            {
                state = tr52;
            }
            else if(Left != 0 || Black ==0 || Right!=0 || Up != 0 || Down!=0 || Blue ==0)
            {
                BSP_LCD_Clear(LCD_COLOR_WHITE);
                BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                BSP_LCD_SetFont(&Font12);
                BSP_LCD_DisplayStringAt(80, 135, (uint8_t *)"Commande erroner : Haut = retour au menu", LEFT_MODE);
                if(Down !=0)state = menu_1_easy_fail;
            }
            break;

            case tr52 :
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            if(Green!=0)state = menu_1_hard_22;
            break;


            case menu_1_hard_22 :
            
            x=0;
            y=0;

            BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(80, 50, (uint8_t *)"Combo = Enchainement termine", LEFT_MODE);
            
            /*BSP_LCD_DrawRect(80,135,160,90);
            BSP_LCD_FillRect(80,135,160,90);*/
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(90, 180, (uint8_t *)"Rejouer", LEFT_MODE);

            /*BSP_LCD_DrawRect(240,135,160,90);
            BSP_LCD_FillRect(240,135,160,90);*/
            BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            BSP_LCD_SetFont(&Font16);
            BSP_LCD_DisplayStringAt(320, 180, (uint8_t *)"Menu", LEFT_MODE);

            BSP_TS_GetState(&TS_State);
            for (idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[0];
                y = TS_State.touchY[0];
            }

            if(Left !=0 ) state = tr53;
            else if(Right !=0 ) state = tr54;

            break;


            case tr54:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            HAL_Delay(150);
            if(Right == 0)state = menu_1_hard_1;
            break;

            case tr53:
            BSP_LCD_Clear(LCD_COLOR_WHITE);
            HAL_Delay(150);
            state = title_0;
            break;
        }
    }
}